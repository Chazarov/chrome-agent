export const ZIP_NAME = "GigaBrowserAgent.zip";
