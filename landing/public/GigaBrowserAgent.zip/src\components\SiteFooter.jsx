import { useState } from "react";
import { Link } from "react-router-dom";
import { useCookieConsent } from "../context/CookieConsentContext.jsx";

export default function SiteFooter() {
  const { openCookiePreferences } = useCookieConsent();
  const [email, setEmail] = useState("");
  const [consentPd, setConsentPd] = useState(false);
  const [consentThird, setConsentThird] = useState(false);
  const [done, setDone] = useState(false);

  function submitNewsletter(e) {
    e.preventDefault();
    if (!consentPd || !consentThird) return;
    setDone(true);
  }

  return (
    <footer className="site-footer">
      <div className="wrap footer-grid">
        <div className="footer-col footer-brand">
          <div className="logo footer-logo">
            <span className="logo-mark" aria-hidden />
            <span>GigaBrowser Agent</span>
          </div>
          <p className="footer-tagline">Проектный практикум · ИИ-безопасность в браузере</p>
        </div>

        <div className="footer-col">
          <h3 className="footer-heading">Документы</h3>
          <nav className="footer-nav" aria-label="Юридическая информация">
            <Link to="/privacy">Политика обработки персональных данных</Link>
            <Link to="/cookies">Политика в отношении cookie</Link>
            <button type="button" className="footer-link-btn" onClick={openCookiePreferences}>
              Настройки cookie
            </button>
            <Link to="/" state={{ scrollTo: "contact" }}>
              Форма обратной связи
            </Link>
          </nav>
        </div>

        <div className="footer-col footer-newsletter">
          <h3 className="footer-heading">Подписка на новости</h3>
          {done ? (
            <p className="footer-note">Запрос учтён (демо: фактическая рассылка требует подключения сервиса отправки).</p>
          ) : (
            <form className="newsletter-form" onSubmit={submitNewsletter}>
              <label className="field footer-field">
                <span className="visually-hidden">E-mail</span>
                <input
                  className="field-input"
                  type="email"
                  name="newsletter_email"
                  autoComplete="email"
                  placeholder="E-mail"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </label>
              <label className="consent-row consent-row-compact">
                <input
                  type="checkbox"
                  checked={consentPd}
                  onChange={(e) => setConsentPd(e.target.checked)}
                  required
                />
                <span>
                  Согласен(на) на обработку e-mail в целях направления информационных и новостных материалов, срок — до
                  отзыва; ознакомлен(а) с <Link to="/privacy">Политикой</Link>.
                </span>
              </label>
              <label className="consent-row consent-row-compact">
                <input
                  type="checkbox"
                  checked={consentThird}
                  onChange={(e) => setConsentThird(e.target.checked)}
                  required
                />
                <span>
                  Отдельное согласие на передачу e-mail оператору рассылки / ESP при подключении соответствующего
                  сервиса (перечень в Политике).
                </span>
              </label>
              <button type="submit" className="btn btn-ghost btn-block" disabled={!consentPd || !consentThird}>
                Подписаться
              </button>
            </form>
          )}
        </div>
      </div>

      <div className="wrap footer-bottom">
        <span>© {new Date().getFullYear()} GigaBrowser Agent</span>
        <span className="mono">GigaChat</span>
      </div>
    </footer>
  );
}
